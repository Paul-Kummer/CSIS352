#pragma once
#include <math.h>
#include "../token/token.h"

class AbstractNode 
{
	public:
		virtual double eval() = 0;
		AbstractNode() {};
		virtual ~AbstractNode() {};
};

class LeafNode : public AbstractNode 
{
	private:
		Token value;
	public:
		LeafNode(Token d) : value(d) {};
		~LeafNode() {};
		double eval() 
		{
			return value.Operand();
		};
};

class UnaryMinusNode : public AbstractNode 
{
	private:
		AbstractNode * child;
	public:
		UnaryMinusNode(AbstractNode * c) : child(c) {};
		~UnaryMinusNode() {delete child;};
		virtual double eval() 
		{
			return ((-1.0)*child->eval());
		};
};

class BinaryNode : public AbstractNode 
{
	private:
		AbstractNode * left;
		AbstractNode * right;
		Token op;
	public:
		BinaryNode(AbstractNode * l,AbstractNode * r,Token o) : left(l), right(r), op(o) {};
		~BinaryNode() 
		{
			delete left; 
			delete right;
		};
		virtual double eval() 
		{
			//Maybe add an enum to support ** as exponent
			switch(op.Operator()) 
			{
				case '+':
					return left->eval()+right->eval();
				case '-':
					return left->eval()-right->eval();
				case '*':
					return left->eval()*right->eval();
				case '/':
					return left->eval()/right->eval();
				case '%':
					return fmod(left->eval(), right->eval());
				case '^':
					return pow(left->eval(), right->eval());
				default:
					return 0;
			};
		};
};

/*
int main() 
{
	AbstractNode * expr = new BinaryNode //will perform the executions of an expression
	(
		new LeafNode(10) //create a node with a double value of 10
		, new UnaryMinusNode(new LeafNode(5)) //returns the negative value of the LeafNode passed into it
		, '+' //add LeafNode(10) to UnaryMinusNode(* LeafNode(5)), returns 5
	);

	cout << expr->eval() << endl;
	delete expr;
	return 0;
};
*/
